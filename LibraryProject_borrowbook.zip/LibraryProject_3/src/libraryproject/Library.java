/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class Library {
    private static List<Book> books;
    private static List<Member> members;
    private List<Employee> employees;
    private Map<Book, Integer> bookCount;
    private static List<BorrowedBook> borrowedBooks;
    private static Member currentMember;
    private static final int MAX_BORROWED_BOOKS = 3;
    private static final String USER_FILE = "C:\\Users\\dlwan\\OneDrive\\Desktop\\lol\\ok.txt";
    private static final String LIBRARY_FILE = "C:\\Users\\dlwan\\OneDrive\\Desktop\\lol\\output.txt";
    
    public Library() {
        books = new ArrayList<>();
        members = new ArrayList<>();
        employees = new ArrayList<>();
        bookCount = new HashMap<>();
        currentMember = null;
    }
    
    
    public Library(List<Book> books, List<Member> members, List<Employee> employees) {
    this.books = books;
    this.members = members;
    this.employees = employees;
    this.bookCount = new HashMap<>();
    this.borrowedBooks = new ArrayList<>();
    
    // Initialize book count map with all books and their counts set to zero
    for (Book book : books) {
        this.bookCount.put(book, 0);
    }
}
    
    

   
    
    //Employee methods:
    
  public static void addBook() {
    Scanner input = new Scanner(System.in);
    try {
        System.out.print("Enter book title: ");
        String title = input.nextLine();

        System.out.print("Enter author: ");
        String author = input.nextLine();

        System.out.print("Enter Id: ");
        int bookId = input.nextInt();
        input.nextLine();

        // check if book with given ID already exists
        boolean bookExists = false;
        for (Book book : books) {
            if (book.getId() == bookId) {
                bookExists = true;
                break;
            }
        }
        if (bookExists) {
            System.out.println("Book with ID " + bookId + " already exists in the library.");
            return;
        }

        System.out.print("Enter publisher: ");
        String publisher = input.nextLine();

        System.out.print("Enter year published: ");
        int yearPublished = input.nextInt();
        input.nextLine();
        
        System.out.print("Is this book available to be borrowed? (y or n): ");
        String YorN = input.next();
        boolean b;
        if(YorN.equalsIgnoreCase("y")){
            b= true;
        }else{
            b= false;
        }
        input.nextLine();


        Book newBook = new Book(title, author, bookId, publisher, yearPublished, b);
        books.add(newBook);

        // write book information to library.txt
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE, true));
            writer.write(newBook.getTitle() + " " + newBook.getAuthor() + " " + newBook.getId() + " " +
                    newBook.getPublisher() + " " + newBook.getYear() + " " + newBook.isAvailable());
            writer.newLine(); //  <-------------------------------------------------------------------------------------
            writer.close();
            System.out.println("New book " + title + " added to the library.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to add book to library.");
        }

    } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
    }
}
    
    
  public static void removeBook() {
    Scanner input = new Scanner(System.in);
    try {
        System.out.print("Enter ID of book to remove: ");
        int bookId = input.nextInt();
        input.nextLine();

        // find book with given ID
        boolean bookFound = false;
        int indexToRemove = -1;
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getId() == bookId) {
                bookFound = true;
                indexToRemove = i;
                break;
            }
        }

        if (!bookFound) {
            System.out.println("Book with ID " + bookId + " not found in the library.");
            return;
        }

        // remove book from books list
        Book removedBook = books.remove(indexToRemove);

        // remove book from library.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
            StringBuilder sb = new StringBuilder();

            String line = reader.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                if (Integer.parseInt(parts[2]) != bookId) {
                    sb.append(line).append('\n');
                }
                line = reader.readLine();
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
            writer.write(sb.toString());
            writer.close();

            System.out.println("Book " + removedBook.getTitle() + " removed from the library.");

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to remove book from library.");
        }

    } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a valid integer for book ID.");
    }
}
    
    
    
    
public static void registerMember() {
    Scanner input = new Scanner(System.in);

    System.out.println("\n===== REGISTER NEW MEMBER =====");
    System.out.print("Enter member name: ");
    String name = input.nextLine();

    Member newMember = new Member(name);
    members.add(newMember);

    System.out.println("\nMember successfully registered.");
    
    try {
        FileWriter writer = new FileWriter(USER_FILE, true);
        writer.write("member-" + newMember.getName() + "\n");
        writer.write(System.lineSeparator()); // write newline character
        writer.close();
        System.out.println("\nMember successfully registered.");
    } catch (IOException e) {
        System.out.println("\nAn error occurred while writing to the file. Member registration failed.");
    }
}
    

public static void removeMember() {
    Scanner input = new Scanner(System.in);

    System.out.println("\n===== REMOVE MEMBER =====");
    System.out.print("Enter member name: ");
    String memberName = input.nextLine();

    boolean memberFound = false;
    for (Iterator<Member> iterator = members.iterator(); iterator.hasNext();) {
        Member member = iterator.next();
        if (member.getName().equalsIgnoreCase(memberName)) {
            iterator.remove();
            memberFound = true;
            break;
        }
    }

    if (memberFound) {
        try {
            FileWriter writer = new FileWriter(USER_FILE, false);

            // write updated member list to file
            for (Member member : members) {
                writer.write("member-" + member.getName() + "\n");
                writer.write(System.lineSeparator());
            }

            writer.close();
            System.out.println("\nMember with name " + memberName + " successfully removed.");
        } catch (IOException e) {
            System.out.println("\nAn error occurred while writing to the file. Member removal failed.");
        }
    } else {
        System.out.println("\nMember with name " + memberName + " not found in the library.");
    }
}
    
public static void viewMembersList() {
    System.out.println("\n===== MEMBER LIST =====");
    try {
        BufferedReader reader = new BufferedReader(new FileReader(USER_FILE));
        String line;
        boolean hasMembers = false;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts[0].startsWith("member-")) {
                String name = parts[0].substring(7);
                String id = parts[1];
                System.out.println("Name: " + name + ", ID: " + id);
                hasMembers = true;
            }
        }
        reader.close();
        if (!hasMembers) {
            System.out.println("No members registered.");
        }
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Failed to read user accounts.");
    }
} 
    

public static void sortUserFile() {
        List<String> lines = new ArrayList<>();

        // Read the contents of the user.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(USER_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read user.txt file.");
            return;
        }

        // Sort the lines using bubble sort
        int n = lines.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                String currentLine = lines.get(j);
                String nextLine = lines.get(j + 1);
                if (currentLine.compareTo(nextLine) > 0) {
                    // Swap lines
                    String temp = currentLine;
                    lines.set(j, nextLine);
                    lines.set(j + 1, temp);
                }
            }
        }

        // Write the sorted lines back to the user.txt file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE));
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            System.out.println("user.txt file sorted successfully.");
        } catch (IOException e) {
            System.out.println("Failed to write to user.txt file.");
        }
    }

    public static void sortLibrary() {
        List<String> lines = new ArrayList<>();

        // Read the contents of the user.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library.txt file.");
            return;
        }

        // Sort the lines using bubble sort
        int n = lines.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                String currentLine = lines.get(j);
                String nextLine = lines.get(j + 1);
                if (currentLine.compareTo(nextLine) > 0) {
                    // Swap lines
                    String temp = currentLine;
                    lines.set(j, nextLine);
                    lines.set(j + 1, temp);
                }
            }
        }

        // Write the sorted lines back to the user.txt file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            System.out.println("library.txt file sorted successfully.");
        } catch (IOException e) {
            System.out.println("Failed to write to library.txt file.");
        }
    }
    // Existing code

 
    
    
    
    
    //Member methods: 
    


public static void viewBooks() {
    System.out.println("\n===== BOOKS IN LIBRARY =====");
    if (books.isEmpty()) {
        System.out.println("No books available in the library.");
    } else {
        for (Book book : books) {
            System.out.println(book);
        }
    }
}
    
  public static void borrowBook() throws IOException {
    Scanner input = new Scanner(System.in);
    System.out.println("\n===== BORROW BOOK =====");
    viewBooks();

    System.out.print("\nEnter the ID of the book you want to borrow: ");
    int bookId = input.nextInt();

    // check if book is available
    boolean bookFound = false;
    Book borrowedBook = null;
    for (Book book : books) {
        if (book.getId() == bookId) {
            if (book.isAvailable()) {
                borrowedBook = book;
                bookFound = true;
                book.setAvailable(false);
                boolean ok = false;
                Library.changeBookAvailability(bookId,ok);
                System.out.println("The book has been borrowed successfully.");
                break;
            } else {
                System.out.println("The book is not available for borrowing.");
                return;
            }
        }
    }

    if (!bookFound) {
        System.out.println("Book not found.");
        return;
    }
    
    
    // check if member has not exceeded maximum number of borrowed books
    /*if (currentMember.getBorrowedBooks().size() >= MAX_BORROWED_BOOKS) {
        System.out.println("You have exceeded the maximum number of borrowed books.");
        return;
    }

    // add book to member's borrowed books list and update book's availability
    currentMember.addBorrowedBook(borrowedBook);
    borrowedBook.addBorrowerId(currentMember.getId());
    borrowedBook.setAvailable(false);
    System.out.println("The book has been borrowed successfully.");*/
}


public static void searchBook() {
    Scanner input = new Scanner(System.in);

    System.out.println("\n===== SEARCH BOOK =====");
    System.out.print("Enter search query: ");
    String query = input.nextLine();

    List<Book> filteredBooks = new ArrayList<>();
    for (Book book : books) {
        if (book.getTitle().toLowerCase().contains(query.toLowerCase()) || book.getAuthor().toLowerCase().contains(query.toLowerCase())) {
            filteredBooks.add(book);
        }
    }

    if (filteredBooks.size() > 0) {
        System.out.println("\nSearch results:");
        for (Book book : filteredBooks) {
            System.out.println(book);
        }
    } else {
        System.out.println("\nNo results found.");
    }
}

public void loadBooksFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String title = parts[0];
                    String author = parts[1];
                    int bookId = Integer.parseInt(parts[2]);
                    String publisher = parts[3];
                    int yearPublished = Integer.parseInt(parts[4]);
                    boolean available = Boolean.parseBoolean(parts[5]);

                    Book book = new Book(title, author, bookId, publisher, yearPublished, available);
                    books.add(book);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }

    public void loadMembersFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(USER_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String username = parts[0];
                    String password = parts[1];

                    Member m = new Member(username, password);
                    members.add(m);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }
    
    public static void changeBookAvailability(int id, boolean newValue) {
    File file = new File(LIBRARY_FILE);
    List<String> lines = new ArrayList<>();

    try (Scanner scanner = new Scanner(file)) {
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parts = line.split("\\s+");
            if (parts.length >= 4 && Integer.parseInt(parts[2]) == id) {//parts.length >= 2 && 
                System.out.println("change worked");
                parts[5] = String.valueOf(newValue);
                line = String.join(" ", parts);
            }
            lines.add(line);
        }
    } catch (FileNotFoundException e) {
        System.out.println("File not found!");
        return;
    }
    try (PrintWriter writer = new PrintWriter(file)) {
        for (String line : lines) {
            writer.println(line);
        }
    } catch (FileNotFoundException e) {
        System.out.println("File not found!");
    }
}
    

    
    /*public static void changeBookAvailability(int id, boolean newAvailability) throws IOException {
    List<String> lines = Files.readAllLines(Paths.get(LIBRARY_FILE));
    for (int i = 0; i < lines.size(); i++) {
        String[] parts = lines.get(i).split(",");
        if (parts[0].equals(id)) { // assuming the ID is the first variable
            parts[5] = String.valueOf(newAvailability); // assuming the boolean is the 5th variable
            System.out.println(newAvailability);
            lines.set(i, String.join(",", parts));
            break;
        }
    }
    Files.write(Paths.get(LIBRARY_FILE), lines);
}*/
   

    public static List<Book> getBooks() {
        return books;
    }

    public static void setBooks(List<Book> books) {
        Library.books = books;
    }

    public static List<Member> getMembers() {
        return members;
    }

    public static void setMembers(List<Member> members) {
        Library.members = members;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Map<Book, Integer> getBookCount() {
        return bookCount;
    }

    public void setBookCount(Map<Book, Integer> bookCount) {
        this.bookCount = bookCount;
    }

    public static List<BorrowedBook> getBorrowedBooks() {
        return borrowedBooks;
    }

    public static void setBorrowedBooks(List<BorrowedBook> borrowedBooks) {
        Library.borrowedBooks = borrowedBooks;
    }

    public static Member getCurrentMember() {
        return currentMember;
    }

    public static void setCurrentMember(Member currentMember) {
        Library.currentMember = currentMember;
    }




}


/*
public void addBook(Book book) {
        books.add(book);
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void displayBooks() {
        System.out.println("Available Books:");
        for (Book book : books) {
            int count = bookCount.get(book);
            if (count > 0) {
                System.out.println(book + " - Copies Available: " + count);
            }
        }
    }

    public void displayMembers() {
        System.out.println("Library Members:");
        for (Member member : members) {
            System.out.println(member);
        }
    }

    public void displayEmployees() {
        System.out.println("Library Employees:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    public boolean issueBook(Book book, Member member) {
        int count = bookCount.getOrDefault(book, 0);
        if (count > 0) {
            bookCount.put(book, count - 1);
            member.addBook(book);
            return true;
        } else {
            return false;
        }
    }

    public boolean returnBook(Book book, Member member) {
        int count = bookCount.getOrDefault(book, 0);
        if (member.hasBook(book) && count >= 0) {
            bookCount.put(book, count + 1);
            member.removeBook(book);
            return true;
        } else {
            return false;
        }
    }
    
    */