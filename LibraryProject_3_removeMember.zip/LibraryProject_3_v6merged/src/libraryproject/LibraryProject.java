/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class LibraryProject {
    public static final String USER_FILE = "C:\\Users\\dlwan\\OneDrive\\Desktop\\lol\\ok.txt";
    public static final String LIBRARY_FILE = "C:\\Users\\dlwan\\OneDrive\\Desktop\\lol\\output.txt";
    
    public static void main(String[] args) throws IOException {
        Library library = new Library();
        library.loadBooksFromFile();
        library.loadMembersFromFile();
        
        /*only works during the running project, doesn't load aftewards
        library.loadMagazinesFromFile();
        library.loadCDsFromFile();*/
        
        
        Scanner scanner = new Scanner(System.in);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<String, String> loginInfo = readLoginInfoFromFile(USER_FILE);

        boolean shouldExit = false;
        while (!shouldExit) {
            boolean loggedIn = false;
            String userType = null;

            while (!loggedIn) {
                System.out.println("Please select a login type");
                System.out.println("1. Owner");
                System.out.println("2. Employee");
                System.out.println("3. Member");
                System.out.println("4. Create Member Account");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                try {
                    int choice = scanner.nextInt();
                    switch (choice) {
                        case 1:
                            userType = "owner";
                            loggedIn = true;
                            break;
                        case 2:
                            userType = "employee";
                            loggedIn = true;
                            break;
                        case 3:
                            userType = "member";
                            loggedIn = true;
                            break;
                        case 4:
                            createMemberAccount(loginInfo);
                            continue;
                        case 5:
                            shouldExit = true;
                            break;
                         case 6:
                            createOwnerAccount(loginInfo);
                            continue;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                            continue; // Goes back to the initial menu
                    }

                    if (shouldExit || choice == 5) {
                        break;
                    }

                    if (!loggedIn) {
                        continue; // Goes back to the initial menu
                    }
                    
                    System.out.print("Username: ");
                    String username = reader.readLine();
                    System.out.print("Password: ");
                    String password = reader.readLine();
                    
                    if (loginInfo.containsKey(userType + "-" + username) &&
                            loginInfo.get(userType + "-" + username).equals(password)) {
                        System.out.println("Login successful!");
                        loggedIn = true;
                    } else {
                        System.out.println("Invalid username or password. Please try again.");
                        loggedIn = false; // Resets loggedIn flag
                        break; // Goes back to the initial menu
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next();
                    continue;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (shouldExit || !loggedIn) {
                continue; // Goes back to the initial menu
            }

            switch (userType) {
                case "owner":
                    MenuManager.ownerMenu();
                    break;
                case "employee":
                    MenuManager.employeeMenu();
                    break;
                case "member":
                    MenuManager.memberMenu();
                    break;
                default:
                    System.out.println("Invalid user type.");
                    break;
            }

        }
    }

    private static void createOwnerAccount(Map<String, String> loginInfo) {
    createAccount(loginInfo, "owner");
    }

    private static void createMemberAccount(Map<String, String> loginInfo) {
    createAccount(loginInfo, "member");
    }

    private static void createAccount(Map<String, String> loginInfo, String userType) {
    Scanner scanner = new Scanner(System.in);
    String interfaceText = (userType.equals("owner")) ? "\n===== shhhhhh! Secret Owner Creation page o_O =====" : "\n===== Member Account Creation =====";
    System.out.println(interfaceText);
    
    System.out.print("Enter username: ");
    String username = scanner.nextLine();

    if (loginInfo.containsKey(userType + "-" + username)) {
        System.out.println("Username already exists. Please try again with a different username.");
        return;
    }

    System.out.print("Enter password: ");
    String password = scanner.nextLine();

    // Adds the new account's login info to the loginInfo map
    loginInfo.put(userType + "-" + username, password);

    // Writes the new login info to the user.txt file
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE, true));
        writer.write(userType + "-" + username + "," + password);
        writer.newLine();
        writer.close();
        System.out.println(userType + " account created successfully!");
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error creating " + userType + " account. Please try again.");
    }

    System.out.println();
}

    /*
    private static void createMemberAccount(Map<String, String> loginInfo) {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter username: ");
    String username = scanner.nextLine();

    if (loginInfo.containsKey("member-" + username)) {
        System.out.println("Username already exists. Please try again with a different username.");
        return;
    }

    System.out.print("Enter password: ");
    String password = scanner.nextLine();

    // Add the new member's login info to the loginInfo map
    loginInfo.put("member-" + username, password);

    // Write the new login info to the user.txt file
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE, true));
        writer.write("member-" + username + "," + password);
        writer.newLine();
        writer.close();
        System.out.println("Member account created successfully!");
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error creating member account. Please try again.");
    }
    
    System.out.println();
}
   */ 
    
    
    //NOTE TO SELF: USER.TXT MUST INCLUDE A SKIPPED LINE BY HAND IN ORDER TO WORK (SPENT 40 MINS TRYING TO FIGURE THIS OUT) 
    
     private static Map<String, String> readLoginInfoFromFile(String fileName) {
        Map<String, String> loginInfo = new HashMap<>();
        
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                loginInfo.put(tokens[0], tokens[1]);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return loginInfo;
    }
}
