/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class Library {

    //
    private List<LibraryItem> items;

    private static List<LibraryItem> books;
    private static List<Member> members;

    private List<Employee> employees;

    private static List<LibraryItem> magazines;
    private static List<LibraryItem> cds;

    private Map<LibraryItem, Integer> bookCount;

    private Map<LibraryItem, Integer> magazineCount;
    private Map<LibraryItem, Integer> cdCount;

    private static List<BorrowedBook> borrowedBooks;
    private static Member currentMember;
    private static final int MAX_BORROWED_BOOKS = 3;

    public Library() {

        //
        items = new ArrayList<>();

        books = new ArrayList<>();

        magazines = new ArrayList<>();
        cds = new ArrayList<>();

        members = new ArrayList<>();
        employees = new ArrayList<>();

        bookCount = new HashMap<>();
        magazineCount = new HashMap<>();
        cdCount = new HashMap<>();

        currentMember = null;
    }

    public Library(List<LibraryItem> books, List<LibraryItem> magazines, List<LibraryItem> cds, List<Member> members, List<Employee> employees) {
        this.books = books;
        this.magazines = magazines;
        this.cds = cds;
        this.members = members;
        this.employees = employees;
        this.bookCount = new HashMap<>();
        this.magazineCount = new HashMap<>();
        this.cdCount = new HashMap<>();

        this.borrowedBooks = new ArrayList<>();

        // Initialize book count map with all books and their counts set to zero
        for (LibraryItem book : books) {
            this.bookCount.put(book, 0);
        }
        for (LibraryItem magazine : magazines) {
            this.magazineCount.put(magazine, 0);
        }
        for (LibraryItem cd : cds) {
            this.cdCount.put(cd, 0);
        }
    }

    //Employee methods:
    public static void addBook() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter book title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int bookId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean bookExists = false;
            for (LibraryItem book : books) {
                if (book.getId() == bookId) {
                    bookExists = true;
                    break;
                }
            }
            if (bookExists) {
                System.out.println("Book with ID " + bookId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            //merged
            System.out.print("Is this book available to be borrowed? (y or n): ");
            String YorN = input.next();
            boolean b;
            if (YorN.equalsIgnoreCase("y")) {
                b = true;
            } else {
                b = false;
            }
            input.nextLine();

            //b added
            Book newBook = new Book(bookId, title, author, publisher, yearPublished, b);
            books.add(newBook);

            // write book information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE, true));
                writer.write(newBook.getTitle() + " " + newBook.getAuthor() + " " + newBook.getId() + " "
                        + newBook.getPublisher() + " " + newBook.getYear() + " " + newBook.isAvailable());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New book " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add book to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    //Magazines
    public static void addMagazines() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter Magazine title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int magazineId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean bookExists = false;
            for (LibraryItem magazine : magazines) {
                if (magazine.getId() == magazineId) {
                    bookExists = true;
                    break;
                }
            }
            if (bookExists) {
                System.out.println("Magazine with ID " + magazineId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            System.out.print("Is this magazine available to be borrowed? (y or n): ");
            String YorN = input.next();
            boolean b;
            if (YorN.equalsIgnoreCase("y")) {
                b = true;
            } else {
                b = false;
            }
            input.nextLine();
            Magazine newMagazine = new Magazine(magazineId, title, author, publisher, yearPublished, b);
            magazines.add(newMagazine);

            // write magazine information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE, true));
                writer.write(newMagazine.getTitle() + " " + newMagazine.getAuthor() + " " + newMagazine.getId() + " "
                        + newMagazine.getPublisher() + " " + newMagazine.getYear() + " " + newMagazine.isAvailable());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New Magazine " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add magazine to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    //CDs
    public static void addCDs() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter CD title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int cdId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean cdExists = false;
            for (LibraryItem cd : cds) {
                if (cd.getId() == cdId) {
                    cdExists = true;
                    break;
                }
            }
            if (cdExists) {
                System.out.println("CD with ID " + cdId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            System.out.print("Is this cd available to be borrowed? (y or n): ");
            String YorN = input.next();
            boolean b;
            if (YorN.equalsIgnoreCase("y")) {
                b = true;
            } else {
                b = false;
            }
            input.nextLine();
            CD newCD = new CD(cdId, title, author, publisher, yearPublished, b);
            cds.add(newCD);

            // write magazine information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE, true));
                writer.write(newCD.getTitle() + " " + newCD.getAuthor() + " " + newCD.getId() + " "
                        + newCD.getPublisher() + " " + newCD.getYear() + " " + newCD.isAvailable());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New CD " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add CD to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    public static void removeBook() {

    }

    public static void removeMagazine() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter ID of magazine to remove: ");
            int magazineId = input.nextInt();
            input.nextLine();

            // find book with given ID
            boolean magazineFound = false;
            int indexToRemove = -1;
            for (int i = 0; i < magazines.size(); i++) {
                LibraryItem magazine = magazines.get(i);
                if (magazine.getId() == magazineId) {
                    magazineFound = true;
                    indexToRemove = i;
                    break;
                }
            }

            if (!magazineFound) {
                System.out.println("Magazine with ID " + magazineId + " not found in the library.");
                return;
            }

            // remove magazine from books list
            LibraryItem removedMagazine = magazines.remove(indexToRemove);

            // remove magazine from library.txt file
            try {
                BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
                StringBuilder sb = new StringBuilder();

                String line = reader.readLine();
                while (line != null) {
                    String[] parts = line.split(",");
                    if (Integer.parseInt(parts[3]) != magazineId) {
                        sb.append(line).append('\n');
                    }
                    line = reader.readLine();
                }
                reader.close();

                BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE));
                writer.write(sb.toString());
                writer.close();

                System.out.println("Magazine " + removedMagazine.getTitle() + " removed from the library.");

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to remove Magazine from library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for book ID.");
        }
    }

    public static void removeCD() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter ID of cd to remove: ");
            int cdId = input.nextInt();
            input.nextLine();

            // find book with given ID
            boolean cdFound = false;
            int indexToRemove = -1;
            for (int i = 0; i < cds.size(); i++) {
                LibraryItem cd = cds.get(i);
                if (cd.getId() == cdId) {
                    cdFound = true;
                    indexToRemove = i;
                    break;
                }
            }

            if (!cdFound) {
                System.out.println("CD with ID " + cdId + " not found in the library.");
                return;
            }

            // remove magazine from books list
            LibraryItem removedCD = cds.remove(indexToRemove);

            // remove magazine from library.txt file
            try {
                BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
                StringBuilder sb = new StringBuilder();

                String line = reader.readLine();
                while (line != null) {
                    String[] parts = line.split(",");
                    if (Integer.parseInt(parts[2]) != cdId) {
                        sb.append(line).append('\n');
                    }
                    line = reader.readLine();
                }
                reader.close();

                BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE));
                writer.write(sb.toString());
                writer.close();

                System.out.println("CD " + removedCD.getTitle() + " removed from the library.");

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to remove CD from library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for book ID.");
        }
    }

    public static void registerMember() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== REGISTER NEW MEMBER =====");
        System.out.print("Enter member name: ");
        String name = input.nextLine();

        Member newMember = new Member(name);
        members.add(newMember);

        System.out.println("\nMember successfully registered.");

        try {
            FileWriter writer = new FileWriter(LibraryProject.USER_FILE, true);
            writer.write("member-" + newMember.getName() + "\n");
            writer.write(System.lineSeparator()); // write newline character
            writer.close();
            System.out.println("\nMember successfully registered.");
        } catch (IOException e) {
            System.out.println("\nAn error occurred while writing to the file. Member registration failed.");
        }
    }

    public static void removeMember() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== REMOVE MEMBER =====");
        System.out.print("Enter member name: ");
        String memberName = input.nextLine();

        boolean memberFound = false;
        for (Iterator<Member> iterator = members.iterator(); iterator.hasNext();) {
            Member member = iterator.next();
            if (member.getName().equalsIgnoreCase(memberName)) {
                iterator.remove();
                memberFound = true;
                break;
            }
        }

        if (memberFound) {
            try {
                FileWriter writer = new FileWriter(LibraryProject.USER_FILE, false);

                // write updated member list to file
                for (Member member : members) {
                    writer.write("member-" + member.getName() + "\n");
                    writer.write(System.lineSeparator());
                }

                writer.close();
                System.out.println("\nMember with name " + memberName + " successfully removed.");
            } catch (IOException e) {
                System.out.println("\nAn error occurred while writing to the file. Member removal failed.");
            }
        } else {
            System.out.println("\nMember with name " + memberName + " not found in the library.");
        }
    }

    public static void viewMembersList() {
        System.out.println("\n===== MEMBER LIST =====");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.USER_FILE));
            String line;
            boolean hasMembers = false;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].startsWith("member-")) {
                    String name = parts[0].substring(7);
                    String id = parts[1];
                    System.out.println("Name: " + name + ", ID: " + id);
                    hasMembers = true;
                }
            }
            reader.close();
            if (!hasMembers) {
                System.out.println("No members registered.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to read user accounts.");
        }
    }

    public static void sortUserFile() {
        List<String> lines = new ArrayList<>();

        // Read the contents of the user.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.USER_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read user.txt file.");
            return;
        }

        // Sort the lines using bubble sort
        int n = lines.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                String currentLine = lines.get(j);
                String nextLine = lines.get(j + 1);
                if (currentLine.compareTo(nextLine) > 0) {
                    // Swap lines
                    String temp = currentLine;
                    lines.set(j, nextLine);
                    lines.set(j + 1, temp);
                }
            }
        }

        // Write the sorted lines back to the user.txt file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.USER_FILE));
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            System.out.println("user.txt file sorted successfully.");
        } catch (IOException e) {
            System.out.println("Failed to write to user.txt file.");
        }
    }

    public static void sortLibrary() {
        List<String> lines = new ArrayList<>();

        // Read the contents of the user.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library.txt file.");
            return;
        }

        // Sort the lines using bubble sort
        int n = lines.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                String currentLine = lines.get(j);
                String nextLine = lines.get(j + 1);
                if (currentLine.compareTo(nextLine) > 0) {
                    // Swap lines
                    String temp = currentLine;
                    lines.set(j, nextLine);
                    lines.set(j + 1, temp);
                }
            }
        }

        // Write the sorted lines back to the user.txt file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.LIBRARY_FILE));
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            System.out.println("library.txt file sorted successfully.");
        } catch (IOException e) {
            System.out.println("Failed to write to library.txt file.");
        }
    }
    // Existing code

    //Member methods: 
    public static void viewBooks() {
        System.out.println("\n===== BOOKS IN LIBRARY =====");
        if (books.isEmpty()) {
            System.out.println("No books available in the library.");
        } else {
            for (LibraryItem book : books) {
                System.out.println(book);
            }
        }
    }
    public static void viewMagazines() {
        System.out.println("\n===== MAGAZINES IN LIBRARY =====");
        if (magazines.isEmpty()) {
            System.out.println("No magazines available in the library.");
        } else {
            for (LibraryItem magazine : magazines) {
                System.out.println(magazine);
            }
        }
    }
        public static void viewCds() {
        System.out.println("\n===== CDS IN LIBRARY =====");
        if (cds.isEmpty()) {
            System.out.println("No cds available in the library.");
        } else {
            for (LibraryItem cd : cds) {
                System.out.println(cd);
            }
        }
    }
    public static void borrowBook() {
        Scanner input = new Scanner(System.in);
        System.out.println("\n===== BORROW BOOK =====");
        viewBooks();

        System.out.print("\nEnter the ID of the book you want to borrow: ");
        int bookId = input.nextInt();

        // check if book is available
        boolean bookFound = false;
        Book borrowedBook = null;
        for (LibraryItem book : books) {
            if (book.getId() == bookId) {
                if (book.getAvail().equals("true")) {
                    borrowedBook = (Book) book;
                    bookFound = true;
                    book.setAvailable(false);
                    book.setAvail("false");
                    boolean ok = false;
                    Library.changeBookAvailability(bookId, ok);
                    System.out.println("The book has been borrowed successfully.");
                    break;
                } else {
                    System.out.println("The book is not available for borrowing.");
                    return;
                }
            }
        }

        if (!bookFound) {
            System.out.println("Book not found.");
            return;
        }
    }
     public static void borrowMagazine() {
        Scanner input = new Scanner(System.in);
        System.out.println("\n===== BORROW MAGAZINE =====");
        viewMagazines();

        System.out.print("\nEnter the ID of the magazine you want to borrow: ");
        int magazineId = input.nextInt();

        // check if magazine is available
        boolean magazineFound = false;
        Magazine borrowedMagazine = null;
        for (LibraryItem magazine : magazines) {
            if (magazine.getId() == magazineId) {
                if (magazine.getAvail().equals("true")) {
                    borrowedMagazine = (Magazine) magazine;
                    magazineFound = true;
                    magazine.setAvailable(false);
                    magazine.setAvail("false");
                    boolean ok = false;
                    Library.changeBookAvailability(magazineId, ok);
                    System.out.println("The magazine has been borrowed successfully.");
                    break;
                } else {
                    System.out.println("The magazine is not available for borrowing.");
                    return;
                }
            }
        }

        if (!magazineFound) {
            System.out.println("Magazine not found.");
            return;
        }
    }   
     public static void borrowCd() {
        Scanner input = new Scanner(System.in);
        System.out.println("\n===== BORROW CD =====");
        viewCds();

        System.out.print("\nEnter the ID of the CD you want to borrow: ");
        int cdId = input.nextInt();

        // check if magazine is available
        boolean cdFound = false;
        Magazine borrowedMagazine = null;
        for (LibraryItem cd : cds) {
            if (cd.getId() == cdId) {
                if (cd.getAvail().equals("true")) {
                    borrowedMagazine = (Magazine) cd;
                    cdFound = true;
                    cd.setAvailable(false);
                    cd.setAvail("false");
                    boolean ok = false;
                    Library.changeBookAvailability(cdId, ok);
                    System.out.println("The CD has been borrowed successfully.");
                    break;
                } else {
                    System.out.println("The CD is not available for borrowing.");
                    return;
                }
            }
        }

        if (!cdFound) {
            System.out.println("CD not found.");
            return;
        }
    }   
    public static void searchBook() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== SEARCH BOOK =====");
        System.out.print("Enter search query: ");
        String query = input.nextLine();

        List<Book> filteredBooks = new ArrayList<>();
        for (LibraryItem book : books) {
            if (book.getTitle().toLowerCase().contains(query.toLowerCase()) || book.getAuthor().toLowerCase().contains(query.toLowerCase())) {
                filteredBooks.add((Book) book);
            }
        }

        if (filteredBooks.size() > 0) {
            System.out.println("\nSearch results:");
            for (Book book : filteredBooks) {
                System.out.println(book);
            }
        } else {
            System.out.println("\nNo results found.");
        }
    }

    public static void searchMagazine() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== SEARCH MAGAZINE =====");
        System.out.print("Enter search query: ");
        String query = input.nextLine();

        List<Magazine> filteredMagazines = new ArrayList<>();
        for (LibraryItem magazine : magazines) {
            if (magazine.getTitle().toLowerCase().contains(query.toLowerCase()) || magazine.getAuthor().toLowerCase().contains(query.toLowerCase())) {
                filteredMagazines.add((Magazine) magazine);
            }
        }

        if (filteredMagazines.size() > 0) {
            System.out.println("\nSearch results:");
            for (Magazine magazine : filteredMagazines) {
                System.out.println(magazine);
            }
        } else {
            System.out.println("\nNo results found.");
        }
    }

    public static void searchCD() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== SEARCH CD =====");
        System.out.print("Enter search query: ");
        String query = input.nextLine();

        List<CD> filteredCDs = new ArrayList<>();
        for (LibraryItem cd : cds) {
            if (cd.getTitle().toLowerCase().contains(query.toLowerCase()) || cd.getAuthor().toLowerCase().contains(query.toLowerCase())) {
                filteredCDs.add((CD) cd);
            }
        }

        if (filteredCDs.size() > 0) {
            System.out.println("\nSearch results:");
            for (CD cd : filteredCDs) {
                System.out.println(cd);
            }
        } else {
            System.out.println("\nNo results found.");
        }
    }    
    
    //merged 
    public void loadBooksFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
            String line;
            //merged
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length >= 5) {
                    String title = parts[0];
                    String author = parts[1];
                    int bookId = Integer.parseInt(parts[2]);
                    String publisher = parts[3];
                    int yearPublished = Integer.parseInt(parts[4]);
                    boolean available = Boolean.parseBoolean(parts[5]);
                    
                    //abstract
                    Book book = new Book(title, author, bookId, publisher, yearPublished, available) {};
                    books.add(book);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }
    public void loadMagazinesFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
            String line;
            //merged
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length >= 5) {
                    String title = parts[0];
                    String author = parts[1];
                    int magazindeId = Integer.parseInt(parts[2]);
                    String publisher = parts[3];
                    int yearPublished = Integer.parseInt(parts[4]);
                    boolean available = Boolean.parseBoolean(parts[5]);
                    
                    //abstract
                    Magazine magazine = new Magazine(title, author, magazindeId, publisher, yearPublished, available) {};
                    magazines.add(magazine);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }
    
    public void loadCDsFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.LIBRARY_FILE));
            String line;
            //merged
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts.length >= 5) {
                    String title = parts[0];
                    String author = parts[1];
                    int cdId = Integer.parseInt(parts[2]);
                    String publisher = parts[3];
                    int yearPublished = Integer.parseInt(parts[4]);
                    boolean available = Boolean.parseBoolean(parts[5]);
                    
                    //abstract
                    CD cd = new CD(title, author, cdId, publisher, yearPublished, available) {};
                    cds.add(cd);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }
    
    public void loadMembersFromFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LibraryProject.USER_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String username = parts[0];
                    String password = parts[1];
                    //password string in member class
                    Member m = new Member(username, password);
                    members.add(m);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Failed to read library file: " + e.getMessage());
        }
    }

    public static void changeBookAvailability(int id, boolean newValue) {
        File file = new File(LibraryProject.LIBRARY_FILE);
        List<String> lines = new ArrayList<>();

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split("\\s+");
                if (parts.length >= 4 && Integer.parseInt(parts[2]) == id) {//parts.length >= 2 && 
                    parts[5] = String.valueOf(newValue);
                    line = String.join(" ", parts);
                }
                lines.add(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
            return;
        }
        try (PrintWriter writer = new PrintWriter(file)) {
            for (String line : lines) {
                writer.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
    }

    public static List<LibraryItem> getBooks() {
        return books;
    }

    public static void setBooks(List<LibraryItem> books) {
        Library.books = books;
    }

    public static List<Member> getMembers() {
        return members;
    }

    public static void setMembers(List<Member> members) {
        Library.members = members;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Map<LibraryItem, Integer> getBookCount() {
        return bookCount;
    }

    public void setBookCount(Map<LibraryItem, Integer> bookCount) {
        this.bookCount = bookCount;
    }

    public static List<BorrowedBook> getBorrowedBooks() {
        return borrowedBooks;
    }

    public static void setBorrowedBooks(List<BorrowedBook> borrowedBooks) {
        Library.borrowedBooks = borrowedBooks;
    }

    public static Member getCurrentMember() {
        return currentMember;
    }

    public static void setCurrentMember(Member currentMember) {
        Library.currentMember = currentMember;
    }

}
