/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class Library {

    private static List<LibraryItem> books;
    private static List<Member> members;

    private List<Employee> employees;

    private static List<LibraryItem> magazines;
    private static List<LibraryItem> cds;

    private Map<LibraryItem, Integer> bookCount;

    private Map<LibraryItem, Integer> magazineCount;
    private Map<LibraryItem, Integer> cdCount;

    private static List<BorrowedBook> borrowedBooks;
    private static Member currentMember;
    private static final int MAX_BORROWED_BOOKS = 3;
    private static final String USER_FILE = "C:\\Users\\echor\\Desktop\\user.txt";
    private static final String LIBRARY_FILE = "C:\\Users\\echor\\Desktop\\library.txt";

    public Library() {
        books = new ArrayList<>();

        magazines = new ArrayList<>();
        cds = new ArrayList<>();

        members = new ArrayList<>();
        employees = new ArrayList<>();

        bookCount = new HashMap<>();
        magazineCount = new HashMap<>();
        cdCount = new HashMap<>();

        currentMember = null;
    }

    public Library(List<LibraryItem> books, List<LibraryItem> magazines, List<LibraryItem> cds, List<Member> members, List<Employee> employees) {
        this.books = books;
        this.magazines = magazines;
        this.cds = cds;
        this.members = members;
        this.employees = employees;
        this.bookCount = new HashMap<>();
        this.magazineCount = new HashMap<>();
        this.cdCount = new HashMap<>();

        this.borrowedBooks = new ArrayList<>();

        // Initialize book count map with all books and their counts set to zero
        for (LibraryItem book : books) {
            this.bookCount.put(book, 0);
        }
        for (LibraryItem magazine : magazines) {
            this.magazineCount.put(magazine, 0);
        }
        for (LibraryItem cd : cds) {
            this.cdCount.put(cd, 0);
        }
    }

    //Employee methods:
    public static void addBook() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter book title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int bookId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean bookExists = false;
            for (LibraryItem book : books) {
                if (book.getId() == bookId) {
                    bookExists = true;
                    break;
                }
            }
            if (bookExists) {
                System.out.println("Book with ID " + bookId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            Book newBook = new Book(bookId, title, author, publisher, yearPublished);
            books.add(newBook);

            // write book information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE, true));
                writer.write(newBook.getTitle() + "," + newBook.getAuthor() + "," + newBook.getId() + ","
                        + newBook.getPublisher() + "," + newBook.getYear());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New book " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add book to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    //Magazines
    public static void addMagazines() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter Magazine title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int magazineId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean bookExists = false;
            for (LibraryItem magazine : magazines) {
                if (magazine.getId() == magazineId) {
                    bookExists = true;
                    break;
                }
            }
            if (bookExists) {
                System.out.println("Magazine with ID " + magazineId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            Magazine newMagazine = new Magazine(magazineId, title, author, publisher, yearPublished);
            magazines.add(newMagazine);

            // write magazine information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE, true));
                writer.write(newMagazine.getTitle() + "," + newMagazine.getAuthor() + "," + newMagazine.getId() + ","
                        + newMagazine.getPublisher() + "," + newMagazine.getYear());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New Magazine " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add magazine to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    //CDs
    public static void addCDs() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter CD title: ");
            String title = input.nextLine();

            System.out.print("Enter author: ");
            String author = input.nextLine();

            System.out.print("Enter Id: ");
            int cdId = input.nextInt();
            input.nextLine();

            // check if book with given ID already exists
            boolean cdExists = false;
            for (LibraryItem cd : cds) {
                if (cd.getId() == cdId) {
                    cdExists = true;
                    break;
                }
            }
            if (cdExists) {
                System.out.println("Magazine with ID " + cdId + " already exists in the library.");
                return;
            }

            System.out.print("Enter publisher: ");
            String publisher = input.nextLine();

            System.out.print("Enter year published: ");
            int yearPublished = input.nextInt();
            input.nextLine();

            CD newCD = new CD(cdId, title, author, publisher, yearPublished);
            cds.add(newCD);

            // write magazine information to library.txt
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE, true));
                writer.write(newCD.getTitle() + "," + newCD.getAuthor() + "," + newCD.getId() + ","
                        + newCD.getPublisher() + "," + newCD.getYear());
                //skips line in txt file
                writer.newLine();
                writer.close();
                System.out.println("New CD " + title + " added to the library.");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to add CD to library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Id, year published, and number of copies.");
        }
    }

    public static void removeBook() {
        Scanner input = new Scanner(System.in);
        /*
    try {
        System.out.print("Enter ID of book to remove: ");
        int bookId = input.nextInt();
        input.nextLine();

        // find book with given ID
        boolean bookFound = false;
        int indexToRemove = -1;
        for (int i = 0; i < books.size(); i++) {
            LibraryItem book = books.get(i);
            if (book.getId() == bookId) {
                bookFound = true;
                indexToRemove = i;
                break;
            }
        }

        if (!bookFound) {
            System.out.println("Book with ID " + bookId + " not found in the library.");
            return;
        }

        // remove book from books list
        LibraryItem removedBook = books.remove(indexToRemove);

        // remove book from library.txt file
        try {
            BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
            StringBuilder sb = new StringBuilder();

            String line = reader.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                if (Integer.parseInt(parts[2]) != bookId) {
                    sb.append(line).append('\n');
                }
                line = reader.readLine();
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
            writer.write(sb.toString());
            writer.close();

            System.out.println("Book " + removedBook.getTitle() + " removed from the library.");

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to remove book from library.");
        }

    } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a valid integer for book ID.");
    }
         */

        //boolean bookRemoved = false;
        // Get username of employee to remove
        //System.out.print("Enter ID of book to remove: ");
        //int bookToRemove = input.nextInt();
        // Read user.txt and remove line with specified username

        boolean bookFound = false;
        System.out.print("Enter ID of book to remove: ");
        int bookId = input.nextInt();
        input.nextLine();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
            /*
            //String line;
            LibraryItem line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith("," + bookToRemove)) {
                    books.add(line);
                } else {
                    bookRemoved = true;
                }
            }
             */

            // find book with given ID
            int indexToRemove = -1;
            for (int i = 0; i < books.size(); i++) {
                LibraryItem book = books.get(i);
                if (book.getId() == bookId) {
                    bookFound = true;
                    indexToRemove = i;
                    break;
                }
            }

            if (!bookFound) {
                System.out.println("Book with ID " + bookId + " not found in the library.");
                return;
            }

            // remove magazine from books list
            LibraryItem removedMagazine = magazines.remove(indexToRemove);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to remove book.");
            return;
        }

        // Write updated user.txt
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
            for (LibraryItem book : books) {
                writer.write(book + "\n");
            }
            writer.close();
            if (bookFound) {
                System.out.println("Book removed successfully!");
            } else {
                System.out.println("Book not found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to remove book.");
        }

    }

    public static void removeMagazine() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter ID of magazine to remove: ");
            int magazineId = input.nextInt();
            input.nextLine();

            // find book with given ID
            boolean magazineFound = false;
            int indexToRemove = -1;
            for (int i = 0; i < magazines.size(); i++) {
                LibraryItem magazine = magazines.get(i);
                if (magazine.getId() == magazineId) {
                    magazineFound = true;
                    indexToRemove = i;
                    break;
                }
            }

            if (!magazineFound) {
                System.out.println("Magazine with ID " + magazineId + " not found in the library.");
                return;
            }

            // remove magazine from books list
            LibraryItem removedMagazine = magazines.remove(indexToRemove);

            // remove magazine from library.txt file
            try {
                BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
                StringBuilder sb = new StringBuilder();

                String line = reader.readLine();
                while (line != null) {
                    String[] parts = line.split(",");
                    if (Integer.parseInt(parts[3]) != magazineId) {
                        sb.append(line).append('\n');
                    }
                    line = reader.readLine();
                }
                reader.close();

                BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
                writer.write(sb.toString());
                writer.close();

                System.out.println("Magazine " + removedMagazine.getTitle() + " removed from the library.");

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to remove Magazine from library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for book ID.");
        }
    }

    public static void removeCD() {
        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter ID of cd to remove: ");
            int cdId = input.nextInt();
            input.nextLine();

            // find book with given ID
            boolean cdFound = false;
            int indexToRemove = -1;
            for (int i = 0; i < cds.size(); i++) {
                LibraryItem cd = cds.get(i);
                if (cd.getId() == cdId) {
                    cdFound = true;
                    indexToRemove = i;
                    break;
                }
            }

            if (!cdFound) {
                System.out.println("CD with ID " + cdId + " not found in the library.");
                return;
            }

            // remove magazine from books list
            LibraryItem removedCD = cds.remove(indexToRemove);

            // remove magazine from library.txt file
            try {
                BufferedReader reader = new BufferedReader(new FileReader(LIBRARY_FILE));
                StringBuilder sb = new StringBuilder();

                String line = reader.readLine();
                while (line != null) {
                    String[] parts = line.split(",");
                    if (Integer.parseInt(parts[2]) != cdId) {
                        sb.append(line).append('\n');
                    }
                    line = reader.readLine();
                }
                reader.close();

                BufferedWriter writer = new BufferedWriter(new FileWriter(LIBRARY_FILE));
                writer.write(sb.toString());
                writer.close();

                System.out.println("CD " + removedCD.getTitle() + " removed from the library.");

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to remove CD from library.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for book ID.");
        }
    }

    public static void registerMember() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== REGISTER NEW MEMBER =====");
        System.out.print("Enter member name: ");
        String name = input.nextLine();

        Member newMember = new Member(name);
        members.add(newMember);

        System.out.println("\nMember successfully registered.");

        try {
            FileWriter writer = new FileWriter(USER_FILE, true);
            writer.write("member-" + newMember.getName() + "\n");
            writer.write(System.lineSeparator()); // write newline character
            writer.close();
            System.out.println("\nMember successfully registered.");
        } catch (IOException e) {
            System.out.println("\nAn error occurred while writing to the file. Member registration failed.");
        }
    }

    public static void removeMember() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== REMOVE MEMBER =====");
        System.out.print("Enter member name: ");
        String memberName = input.nextLine();

        boolean memberFound = false;
        for (Iterator<Member> iterator = members.iterator(); iterator.hasNext();) {
            Member member = iterator.next();
            if (member.getName().equalsIgnoreCase(memberName)) {
                iterator.remove();
                memberFound = true;
                break;
            }
        }

        if (memberFound) {
            try {
                FileWriter writer = new FileWriter(USER_FILE, false);

                // write updated member list to file
                for (Member member : members) {
                    writer.write("member-" + member.getName() + "\n");
                    writer.write(System.lineSeparator());
                }

                writer.close();
                System.out.println("\nMember with name " + memberName + " successfully removed.");
            } catch (IOException e) {
                System.out.println("\nAn error occurred while writing to the file. Member removal failed.");
            }
        } else {
            System.out.println("\nMember with name " + memberName + " not found in the library.");
        }
    }

    public static void viewMembersList() {
        System.out.println("\n===== MEMBER LIST =====");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(USER_FILE));
            String line;
            boolean hasMembers = false;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].startsWith("member-")) {
                    String name = parts[0].substring(7);
                    String id = parts[1];
                    System.out.println("Name: " + name + ", ID: " + id);
                    hasMembers = true;
                }
            }
            reader.close();
            if (!hasMembers) {
                System.out.println("No members registered.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to read user accounts.");
        }
    }

    //Member methods: 
    public static void viewBooks() {
        System.out.println("\n===== BOOKS IN LIBRARY =====");
        
        if (books.isEmpty()) {
            System.out.println("No books available in the library.");
        } else {
       
            for (LibraryItem book : books) {
                System.out.println(book.getTitle() + ", " + book.getAuthor() + ", " + book.getPublisher() + ", " + book.getYear());
            }
            
        }
        

        
    }

    public static void borrowBook() {
        Scanner input = new Scanner(System.in);
        System.out.println("\n===== BORROW BOOK =====");
        viewBooks();

        System.out.print("\nEnter the ID of the book you want to borrow: ");
        int bookId = input.nextInt();

        // check if book is available
        boolean bookFound = false;
        Book borrowedBook = null;
        for (LibraryItem book : books) {
            if (book.getId() == bookId) {
                if (book.isAvailable()) {
                    borrowedBook = (Book) book;
                    bookFound = true;
                    break;
                } else {
                    System.out.println("The book is not available for borrowing.");
                    return;
                }
            }
        }

        if (!bookFound) {
            System.out.println("Book not found.");
            return;
        }

        // check if member has not exceeded maximum number of borrowed books
        if (currentMember.getBorrowedBooks().size() >= MAX_BORROWED_BOOKS) {
            System.out.println("You have exceeded the maximum number of borrowed books.");
            return;
        }

        // add book to member's borrowed books list and update book's availability
        currentMember.addBorrowedBook(borrowedBook);
        borrowedBook.addBorrowerId(currentMember.getId());
        borrowedBook.setAvailable(false);
        System.out.println("The book has been borrowed successfully.");
    }

    public static void searchBook() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n===== SEARCH BOOK =====");
        System.out.print("Enter search query: ");
        String query = input.nextLine();

        List<Book> filteredBooks = new ArrayList<>();
        for (LibraryItem book : books) {
            if (book.getTitle().toLowerCase().contains(query.toLowerCase()) || book.getAuthor().toLowerCase().contains(query.toLowerCase())) {
                filteredBooks.add((Book) book);
            }
        }

        if (filteredBooks.size() > 0) {
            System.out.println("\nSearch results:");
            for (Book book : filteredBooks) {
                System.out.println(book);
            }
        } else {
            System.out.println("\nNo results found.");
        }
    }

}

/*
public void addBook(Book book) {
        books.add(book);
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void displayBooks() {
        System.out.println("Available Books:");
        for (Book book : books) {
            int count = bookCount.get(book);
            if (count > 0) {
                System.out.println(book + " - Copies Available: " + count);
            }
        }
    }

    public void displayMembers() {
        System.out.println("Library Members:");
        for (Member member : members) {
            System.out.println(member);
        }
    }

    public void displayEmployees() {
        System.out.println("Library Employees:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    public boolean issueBook(Book book, Member member) {
        int count = bookCount.getOrDefault(book, 0);
        if (count > 0) {
            bookCount.put(book, count - 1);
            member.addBook(book);
            return true;
        } else {
            return false;
        }
    }

    public boolean returnBook(Book book, Member member) {
        int count = bookCount.getOrDefault(book, 0);
        if (member.hasBook(book) && count >= 0) {
            bookCount.put(book, count + 1);
            member.removeBook(book);
            return true;
        } else {
            return false;
        }
    }
    
 */
