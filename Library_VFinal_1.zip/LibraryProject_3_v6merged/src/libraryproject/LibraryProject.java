/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class LibraryProject {
    public static final String USER_FILE = "C:\\Users\\salki\\OneDrive\\Documents\\users.txt";
    public static final String LIBRARY_FILE = "C:\\Users\\salki\\OneDrive\\Documents\\library.txt";

    public static void main(String[] args) throws IOException {
    Library library = new Library();
    library.loadBooksFromFile();
    library.loadCDsFromFile();
    library.loadMagazinesFromFile();

    LoginManager.initializeLoginInfo();

    Map<String, String> loginInfo = LoginManager.getLoginInfo();

    boolean shouldExit = false;
    while (!shouldExit) {
        boolean loggedIn = false;
        String userType = null;

        while (!loggedIn) {
            System.out.println("Please select a login type");
            System.out.println("1. Owner");
            System.out.println("2. Employee");
            System.out.println("3. Member");
            System.out.println("4. Create Member Account");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = new Scanner(System.in).nextInt();

                switch (choice) {
                    case 1:
                        userType = "owner";
                        loggedIn = true;
                        break;
                    case 2:
                        userType = "employee";
                        loggedIn = true;
                        break;
                    case 3:
                        userType = "member";
                        loggedIn = true;
                        break;
                    case 4:
                        createMemberAccount(loginInfo);
                        continue;
                    case 5:
                        shouldExit = true;
                        break;
                    case 6:
                        createOwnerAccount(loginInfo);
                        continue;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        continue; 
                }

                if (shouldExit || choice == 5) {
                    break;
                }

                if (!loggedIn) {
                    continue; 
                }

                System.out.print("Username: ");
                String username = new BufferedReader(new InputStreamReader(System.in)).readLine();
                System.out.print("Password: ");
                String password = new BufferedReader(new InputStreamReader(System.in)).readLine();

                if (loginInfo.containsKey(userType + "-" + username) &&
                        loginInfo.get(userType + "-" + username).equals(password)) {
                    System.out.println("Login successful!");
                    loggedIn = true;
                } else {
                    System.out.println("Invalid username or password. Please try again.");
                    System.out.println("");
                    loggedIn = false; // <--- resets loggedIn flag
                    break; 
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number for the choice.");
                System.out.println("");
            }
        }

        if (shouldExit || !loggedIn) {
            continue; // goes back to the initial menu
        }

        switch (userType) {
            case "owner":
                MenuManager.ownerMenu(loginInfo);
                break;
            case "employee":
                MenuManager.employeeMenu(loginInfo);
                break;
            case "member":
                MenuManager.memberMenu(loginInfo);
                break;
            default:
                System.out.println("Invalid user type.");
                break;
        }
    }
}

    // Rest of the class code

    private static void createOwnerAccount(Map<String, String> loginInfo) {
    createAccount(loginInfo, "owner");
    }

    public static void createMemberAccount(Map<String, String> loginInfo) {
    createAccount(loginInfo, "member");
    }

    public static void createEmployeeAccount(Map<String, String> loginInfo) {
    createAccount(loginInfo, "employee");
    }
    
    private static void createAccount(Map<String, String> loginInfo, String userType) {
    Scanner scanner = new Scanner(System.in);
    String interfaceText;
    
    switch (userType) {
        case "owner":
            interfaceText = "\n===== shhhhhh! Secret Owner Creation page o_O =====";
            break;
        case "member":
            interfaceText = "\n===== Member Account Creation =====";
            break;
        case "employee":
            interfaceText = "Employee Account Creation:";
            break;
        default:
            System.out.println("Invalid user type.");
            return;
    }

    System.out.println(interfaceText);

    System.out.print("Enter username: ");
    String username = scanner.nextLine();

    if (loginInfo.containsKey(userType + "-" + username)) {
        System.out.println("Username already exists. Please try again with a different username.");
        return;
    }

    System.out.print("Enter password: ");
    String password = scanner.nextLine();

    loginInfo.put(userType + "-" + username, password);
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE, true));
        writer.write(userType + "-" + username + "," + password);
        writer.newLine();
        writer.close();
        System.out.println(userType + " account created successfully!");
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error creating " + userType + " account. Please try again.");
    }

    System.out.println();
}

    
    public static void removeAccount(Map<String, String> loginInfo, String userType) {
    Scanner scanner = new Scanner(System.in);
    String interfaceText;
    
    switch (userType) {
        case "owner":
            interfaceText = "\n===== Owner Account Removal =====";
            break;
        case "member":
            interfaceText = "\n===== Member Account Removal =====";
            break;
        case "employee":
            interfaceText = "Employee Account Removal:";
            break;
        default:
            System.out.println("Invalid user type.");
            return;
    }

    System.out.println(interfaceText);

    System.out.print("Enter username: ");
    String username = scanner.nextLine();

    if (!loginInfo.containsKey(userType + "-" + username)) {
        System.out.println("Username does not exist. Please try again with a valid username.");
        return;
    }

    loginInfo.remove(userType + "-" + username);

    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE));
        for (Map.Entry<String, String> entry : loginInfo.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            writer.write(key + "," + value);
            writer.newLine();
        }
        writer.close();
        System.out.println(userType + " account removed successfully!");
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error removing " + userType + " account. Please try again.");
    }

    System.out.println();
}

    
    //NOTE TO SELF: USER.TXT MUST INCLUDE A SKIPPED LINE BY HAND IN ORDER TO WORK (SPENT 40 MINS TRYING TO FIGURE THIS OUT) 
    
     public static Map<String, String> readLoginInfoFromFile(String fileName) {
        Map<String, String> loginInfo = new HashMap<>();
        
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                loginInfo.put(tokens[0], tokens[1]);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return loginInfo;
    } 
    
}
