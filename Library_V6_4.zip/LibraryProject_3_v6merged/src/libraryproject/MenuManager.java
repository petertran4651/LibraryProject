/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryproject;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author salki
 */
public class MenuManager {

    public static void memberMenu(Map<String, String> loginInfo) throws IOException {
    Scanner input = new Scanner(System.in);

    int choice = 0;
    do {
        try {
            System.out.println("\n===== MEMBER MENU =====");
            System.out.println("1. View Items");
            System.out.println("2. Borrow Item");
            System.out.println("3. Return Item");
            System.out.println("4. Search Item");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    viewItemsMenu();
                    break;
                case 2:
                    Library.borrowBook();
                    break;
                case 3:
                    Library.returnBook();
                    break;
                case 4:
                    Library.searchBook();
                    break;
                case 5:
                    System.out.println("Thank you for using the library system.");
                    System.out.println();
                    Library.sortLibrary();
                    
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            input.nextLine(); // consume invalid input
        }
    } while (choice != 5);
}

    public static void employeeMenu(Map<String, String> loginInfo) {
    Scanner input = new Scanner(System.in);

    int choice = 0;
    do {
        try {
            System.out.println("\n===== EMPLOYEE MENU =====");
            System.out.println("1. Add Library Item");
            System.out.println("2. Remove Library Item");
            System.out.println("3. Register Member");
            System.out.println("4. Remove Member");
            System.out.println("5. View Members");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    AddLibraryItemMenu();
                    break;
                case 2:
                    RemoveLibraryItemMenu();
                    break;
                case 3:
                    LibraryProject.createMemberAccount(loginInfo);
                    break;
                case 4:
                    LibraryProject.removeAccount(loginInfo, "member");
                    break;
                case 5:
                    Library.viewMembersList();
                    break;
                case 6:
                    System.out.println("Thank you for using the library system.");
                    System.out.println();
                    Library.sortUserFile();
                    Library.sortLibrary();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            input.nextLine(); // consume invalid input
        }
    } while (choice != 6);
}

    public static void ownerMenu(Map<String, String> loginInfo) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome, owner!");
        boolean exit = false;

        while (!exit) {
            System.out.println("\nPlease select an option:");
            System.out.println("1. Add employee");
            System.out.println("2. Remove employee");
            System.out.println("3. View all employees");
            System.out.println("4. Logout");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline character

                switch (choice) {
                    case 1:
                        LibraryProject.createEmployeeAccount(loginInfo);
                        break;
                    case 2:
                        LibraryProject.removeAccount(loginInfo, "employee");
                        break;
                    case 3:
                        Owner.viewEmployees();
                        break;
                    case 4:
                        System.out.println("Logging out...");
                        System.out.println();
                        exit = true;
                        // Sort the user.txt file before logging out
                        Library.sortUserFile();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // consume invalid input
            }
        }
    }

    public static void AddLibraryItemMenu() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;

        do {
            System.out.println("\n===== EMPLOYEE MENU =====");
            System.out.println("1. Add Book");
            System.out.println("2. Add Magazine");
            System.out.println("3. Add CD");
            System.out.println("0. Go To Previous Page");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Library.addBook();
                    break;
                case 2:
                    Library.addMagazines();
                    break;

                case 3:
                    Library.addCDs();
                    break;
                case 0:
                    System.out.println("Switched Page.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    public static void RemoveLibraryItemMenu() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;

        do {
            System.out.println("\n===== EMPLOYEE MENU =====");
            System.out.println("1. Remove Book");
            System.out.println("2. Remove Magazine");
            System.out.println("3. Remove CD");
            System.out.println("0. Go To Previous Page");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Library.removeBook();
                    break;
                case 2:
                    Library.removeMagazine();
                    break;

                case 3:
                    Library.removeCD();
                    break;
                case 0:
                    System.out.println("Switched Page.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    public static void viewItemsMenu() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("\n===== ITEM MENU =====");
            System.out.println("1. View Book");
            System.out.println("2. View Magazine");
            System.out.println("3. View CD");
            System.out.println("0. Go To Previous Page");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Library.viewBooks();
                    break;
                case 2:
                    Library.viewMagazines();
                    break;

                case 3:
                    Library.viewCds();
                    break;
                case 0:
                    System.out.println("Switched Page.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

    }
        public static void borrowItemsMenu() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("\n===== ITEM MENU =====");
            System.out.println("1. Borrow Book");
            System.out.println("2. Borrow Magazine");
            System.out.println("3. Borrow CD");
            System.out.println("0. Go To Previous Page");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Library.borrowBook();
                    break;
                case 2:
                    Library.borrowMagazine();
                    break;

                case 3:
                    Library.borrowCd();
                    break;
                case 0:
                    System.out.println("Switched Page.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

    }
    
        //return 
        /*
        public static void returnItemsMenu() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("\n===== ITEM MENU =====");
            System.out.println("1. Return Book");
            System.out.println("2. Return Magazine");
            System.out.println("3. Return CD");
            System.out.println("0. Go To Previous Page");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    //Library.returnBook();
                    break;
                case 2:
                    //Library.returnMagazine();
                    break;

                case 3:
                    //Library.returnCd();
                    break;
                case 0:
                    System.out.println("Switched Page.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

    }    
        */
        
        
        
}
