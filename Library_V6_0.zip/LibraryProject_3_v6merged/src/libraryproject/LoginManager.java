/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


/**
 *
 * @author salki
 */
public class LoginManager {
    private static Map<String, String> loginInfo = new HashMap<>();

    public static void initializeLoginInfo() {
        // Read login info from file and populate the loginInfo map
        loginInfo = readLoginInfoFromFile(LibraryProject.USER_FILE);
    }

    public static Map<String, String> getLoginInfo() {
        return loginInfo;
    }

    public static void addAccount(String userType, String username, String password) {
        String accountKey = userType + "-" + username;
        if (loginInfo.containsKey(accountKey)) {
            System.out.println("Username already exists. Please try again with a different username.");
            return;
        }

        loginInfo.put(accountKey, password);

        // Write the new login info to the user.txt file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(LibraryProject.USER_FILE, true));
            writer.write(accountKey + "," + password);
            writer.newLine();
            writer.close();
            System.out.println(userType + " account created successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error creating " + userType + " account. Please try again.");
        }
    }
    
    public static Map<String, String> readLoginInfoFromFile(String fileName) {
        Map<String, String> loginInfo = new HashMap<>();
        
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                loginInfo.put(tokens[0], tokens[1]);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return loginInfo;
    }
}
